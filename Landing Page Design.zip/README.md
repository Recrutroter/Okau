
  # Landing Page Design

  This is a code bundle for Landing Page Design. The original project is available at https://www.figma.com/design/6wDHpmcUF9Rrvr4OavyCK9/Landing-Page-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  